<?php
// Local / Server specific configuration
// This file should remain on the server and NOT be overwritten by git

define('DB_HOST', 'localhost');
define('DB_USER', 'spectredash_dbusr'); // BURAYA KULLANICI ADINI YAZIN
define('DB_PASS', 'KH]RJd]E36RW');    // BURAYA ŞİFREYİ YAZIN
define('DB_NAME', 'spectredash_db');     // BURAYA VERİTABANI ADINI YAZIN

// AI Key (Optional overwrite)
define('DEEPSEEK_API_KEY', 'sk-38442a8cf1b54d77a8885c4272d1affc');

// API Keys
define('TINYPNG_API_KEY', 'c9qKg3vksXqrRtTYJpPdrHYvMcjKVVpM');
