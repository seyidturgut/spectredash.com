<?php
// Local / Server specific configuration
// This file should remain on the server and NOT be overwritten by git

define('DB_HOST', 'localhost:3306');
define('DB_USER', 'tembelhane_spectreusr'); // BURAYA KULLANICI ADINI YAZIN
define('DB_PASS', 'c_vkdJ@f}.Oc');    // BURAYA ŞİFREYİ YAZIN
define('DB_NAME', 'tembelhane_spectre');     // BURAYA VERİTABANI ADINI YAZIN

// AI Key (Optional overwrite)
define('DEEPSEEK_API_KEY', 'sk-38442a8cf1b54d77a8885c4272d1affc');
