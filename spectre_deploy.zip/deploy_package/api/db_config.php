<?php
// Production Database Configuration
// Auto-generated for deployment

define('DB_HOST', 'localhost:3306');
define('DB_USER', 'spectredash_dbusr');
define('DB_PASS', 'Shi@ShhnM%(M');
define('DB_NAME', 'spectredash_db');

// AI Configuration
// define('DEEPSEEK_API_KEY', 'your-key-here');
