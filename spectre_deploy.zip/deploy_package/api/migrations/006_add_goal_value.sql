ALTER TABLE goal_definitions ADD COLUMN default_value DECIMAL(10,2) DEFAULT 0 AFTER selector_value;
