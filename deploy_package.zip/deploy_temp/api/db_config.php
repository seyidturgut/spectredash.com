<?php
// Local / Server specific configuration
// This file should remain on the server and NOT be overwritten by git

define('DB_HOST', 'localhost');
define('DB_USER', 'spectredash_dbusr'); // BURAYA KULLANICI ADINI YAZIN
define('DB_PASS', 'KH]RJd]E36RW');    // BURAYA ŞİFREYİ YAZIN
define('DB_NAME', 'spectredash_db');     // BURAYA VERİTABANI ADINI YAZIN

// AI Key (Google Gemini - FREE TIER)
// Get key from: https://aistudio.google.com/app/apikey
define('GEMINI_API_KEY', 'AIzaSyA0ud5vL_UovJdaSyRdYjTrwEVQWD7npZQ');


// API Keys
define('TINYPNG_API_KEY', 'c9qKg3vksXqrRtTYJpPdrHYvMcjKVVpM');

define('OPENROUTER_API_KEY', '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');
